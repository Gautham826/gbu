import { Lock, LockOpen, Check } from 'lucide-react';

interface ProgressTrackerProps {
  totalStages: number;
  currentStage: number;
  unlockedStages: boolean[];
}

export default function ProgressTracker({ totalStages, currentStage, unlockedStages }: ProgressTrackerProps) {
  return (
    <div className="flex items-center justify-center gap-3 md:gap-4 p-4">
      {Array.from({ length: totalStages }).map((_, index) => {
        const isUnlocked = unlockedStages[index];
        const isCurrent = index === currentStage;
        const isCompleted = isUnlocked && index < currentStage;
        
        return (
          <div key={index} className="flex items-center gap-2 md:gap-3">
            <div 
              className={`
                relative flex items-center justify-center w-10 h-10 md:w-12 md:h-12 rounded-full border-2 transition-all duration-300
                ${isCurrent ? 'border-primary bg-primary/20 animate-glow' : ''}
                ${isUnlocked && !isCurrent ? 'border-primary bg-primary/10' : ''}
                ${!isUnlocked ? 'border-muted-foreground/30 bg-muted/20' : ''}
              `}
              data-testid={`progress-stage-${index}`}
            >
              {isCompleted ? (
                <Check className="w-5 h-5 md:w-6 md:h-6 text-primary" />
              ) : isUnlocked ? (
                <LockOpen className="w-4 h-4 md:w-5 md:h-5 text-primary" />
              ) : (
                <Lock className="w-4 h-4 md:w-5 md:h-5 text-muted-foreground" />
              )}
              <span className="absolute -bottom-6 text-xs font-medium text-muted-foreground">
                {index + 1}
              </span>
            </div>
            {index < totalStages - 1 && (
              <div className={`h-0.5 w-8 md:w-12 transition-colors duration-300 ${
                isUnlocked ? 'bg-primary' : 'bg-muted-foreground/20'
              }`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

import { useState } from 'react';
import TreasureBackground from './TreasureBackground';
import ProgressTracker from './ProgressTracker';
import TreasureChest from './TreasureChest';
import CompanyDescription from './CompanyDescription';
import UnlockInput from './UnlockInput';
import { CompanyStage } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

interface GameBoardProps {
  initialStages: CompanyStage[];
}

export default function GameBoard({ initialStages }: GameBoardProps) {
  const [stages, setStages] = useState<CompanyStage[]>(initialStages);
  const [currentStage, setCurrentStage] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const { toast } = useToast();

  const handleUnlock = (answer: string) => {
    const currentStageData = stages[currentStage];
    
    if (answer.toLowerCase() === currentStageData.companyName.toLowerCase()) {
      const newStages = [...stages];
      if (currentStage + 1 < stages.length) {
        newStages[currentStage + 1].isUnlocked = true;
        setStages(newStages);
        setCurrentStage(currentStage + 1);
      }
      
      toast({
        title: "🎉 Unlocked!",
        description: `You've discovered ${currentStageData.companyName}!`,
      });
    } else {
      setIsAnimating(true);
      setTimeout(() => setIsAnimating(false), 300);
      
      toast({
        title: "❌ Incorrect",
        description: "That's not the right answer. Try again!",
        variant: "destructive",
      });
    }
  };

  const unlockedStages = stages.map(s => s.isUnlocked);
  const allCompleted = currentStage === stages.length - 1 && stages[stages.length - 1].isUnlocked;

  return (
    <div className="min-h-screen relative">
      <TreasureBackground />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="text-center mb-8 md:mb-12">
          <h1 className="font-serif text-4xl md:text-6xl font-bold text-primary mb-3 md:mb-4">
            Treasure Hunt
          </h1>
          <p className="text-base md:text-xl text-muted-foreground">
            Unlock each stage by discovering the company name from the previous description
          </p>
        </div>

        <div className="mb-8 md:mb-12">
          <ProgressTracker 
            totalStages={stages.length} 
            currentStage={currentStage}
            unlockedStages={unlockedStages}
          />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8 md:mb-12">
          {stages.map((stage, index) => (
            <TreasureChest
              key={stage.id}
              stageNumber={stage.id}
              isLocked={!stage.isUnlocked}
              isActive={index === currentStage}
              onClick={() => {
                if (stage.isUnlocked) {
                  console.log(`Viewing stage ${stage.id}`);
                }
              }}
            />
          ))}
        </div>

        {stages[currentStage].isUnlocked && (
          <div className="mb-8 md:mb-12">
            <CompanyDescription
              companyName={stages[currentStage].companyName}
              description={stages[currentStage].description}
              stageNumber={stages[currentStage].id}
            />
          </div>
        )}

        {!allCompleted && currentStage + 1 < stages.length && (
          <div className="mb-8">
            <UnlockInput
              onSubmit={handleUnlock}
              isLocked={!stages[currentStage + 1].isUnlocked}
              isAnimating={isAnimating}
              placeholder={`Enter the company name from Stage ${currentStage + 1} to unlock Stage ${currentStage + 2}...`}
            />
          </div>
        )}

        {allCompleted && (
          <div className="text-center py-12">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4">
              🎊 Congratulations!
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground">
              You've unlocked all the treasures!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

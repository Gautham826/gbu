import { Lock, LockOpen } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface TreasureChestProps {
  stageNumber: number;
  isLocked: boolean;
  isActive: boolean;
  onClick?: () => void;
}

export default function TreasureChest({ stageNumber, isLocked, isActive, onClick }: TreasureChestProps) {
  return (
    <Card 
      className={`
        relative min-h-32 md:min-h-40 flex flex-col items-center justify-center gap-3 p-6 transition-all duration-300 cursor-pointer
        ${isLocked ? 'opacity-60' : 'border-primary shadow-lg shadow-primary/20'}
        ${isActive && !isLocked ? 'animate-float' : ''}
        ${!isLocked ? 'hover-elevate active-elevate-2' : ''}
      `}
      onClick={onClick}
      data-testid={`chest-stage-${stageNumber}`}
    >
      <div className={`
        text-4xl md:text-5xl transition-all duration-300
        ${isActive && !isLocked ? 'text-primary' : isLocked ? 'text-muted-foreground' : 'text-primary'}
      `}>
        {isLocked ? <Lock className="w-12 h-12 md:w-16 md:h-16" /> : <LockOpen className="w-12 h-12 md:w-16 md:h-16" />}
      </div>
      <p className={`font-serif text-xl md:text-2xl font-semibold ${
        isLocked ? 'text-muted-foreground' : 'text-primary'
      }`}>
        Stage {stageNumber}
      </p>
      {!isLocked && (
        <div className="absolute top-2 right-2">
          <div className="w-3 h-3 rounded-full bg-primary animate-glow" />
        </div>
      )}
    </Card>
  );
}

import UnlockInput from '../UnlockInput';

export default function UnlockInputExample() {
  return (
    <div className="p-8">
      <UnlockInput 
        onSubmit={(answer) => console.log('Submitted:', answer)} 
        isLocked={true}
      />
    </div>
  );
}

import TreasureChest from '../TreasureChest';

export default function TreasureChestExample() {
  return (
    <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
      <TreasureChest stageNumber={1} isLocked={false} isActive={true} />
      <TreasureChest stageNumber={2} isLocked={false} isActive={false} />
      <TreasureChest stageNumber={3} isLocked={true} isActive={false} />
    </div>
  );
}

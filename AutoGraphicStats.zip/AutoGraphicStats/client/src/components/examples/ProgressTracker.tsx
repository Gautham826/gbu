import ProgressTracker from '../ProgressTracker';

export default function ProgressTrackerExample() {
  return (
    <div className="p-8">
      <ProgressTracker 
        totalStages={5} 
        currentStage={2} 
        unlockedStages={[true, true, true, false, false]} 
      />
    </div>
  );
}

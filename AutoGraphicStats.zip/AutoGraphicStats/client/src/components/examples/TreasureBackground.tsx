import TreasureBackground from '../TreasureBackground';

export default function TreasureBackgroundExample() {
  return (
    <div className="relative h-screen">
      <TreasureBackground />
      <div className="relative z-10 flex items-center justify-center h-full">
        <p className="text-4xl font-serif font-bold text-primary">Treasure Background</p>
      </div>
    </div>
  );
}

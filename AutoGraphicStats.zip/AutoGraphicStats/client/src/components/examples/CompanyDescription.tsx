import CompanyDescription from '../CompanyDescription';

export default function CompanyDescriptionExample() {
  return (
    <div className="p-8 max-w-3xl">
      <CompanyDescription 
        companyName="Google" 
        description="A multinational technology company that specializes in Internet-related services and products, which include online advertising technologies, search engine, cloud computing, software, and hardware."
        stageNumber={1}
      />
    </div>
  );
}

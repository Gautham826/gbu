import treasureMapBg from '@assets/stock_images/ancient_treasure_map_9c4bbd3b.jpg';

export default function TreasureBackground() {
  return (
    <div 
      className="fixed inset-0 -z-10 bg-cover bg-center bg-fixed"
      style={{ backgroundImage: `url(${treasureMapBg})` }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/70 to-background/90" />
    </div>
  );
}

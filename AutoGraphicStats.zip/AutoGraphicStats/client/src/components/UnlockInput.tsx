import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Key } from 'lucide-react';

interface UnlockInputProps {
  onSubmit: (answer: string) => void;
  isLocked: boolean;
  isAnimating?: boolean;
  placeholder?: string;
}

export default function UnlockInput({ onSubmit, isLocked, isAnimating = false, placeholder = "Enter company name to unlock..." }: UnlockInputProps) {
  const [answer, setAnswer] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (answer.trim()) {
      onSubmit(answer.trim());
      setAnswer('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto space-y-4">
      <div className="relative">
        <Input
          type="text"
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder={placeholder}
          disabled={!isLocked}
          className={`
            h-12 md:h-14 text-base md:text-lg border-2 pr-12
            ${isAnimating ? 'animate-shake' : ''}
            ${isLocked ? 'border-primary focus-visible:ring-primary' : 'border-muted'}
          `}
          data-testid="input-unlock"
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2">
          <Key className={`w-5 h-5 transition-colors ${isLocked ? 'text-primary' : 'text-muted-foreground'}`} />
        </div>
      </div>
      <Button 
        type="submit" 
        disabled={!isLocked || !answer.trim()}
        className="w-full h-12 md:h-14 text-base md:text-lg font-semibold"
        variant="default"
        data-testid="button-unlock"
      >
        🔓 Unlock Treasure
      </Button>
    </form>
  );
}

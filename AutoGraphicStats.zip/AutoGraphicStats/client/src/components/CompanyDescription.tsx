import { Card } from '@/components/ui/card';
import { Building2 } from 'lucide-react';

interface CompanyDescriptionProps {
  companyName: string;
  description: string;
  stageNumber: number;
}

export default function CompanyDescription({ companyName, description, stageNumber }: CompanyDescriptionProps) {
  return (
    <Card className="p-6 md:p-8 border-primary animate-fade-up" data-testid={`description-${stageNumber}`}>
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0">
          <div className="w-12 h-12 md:w-16 md:h-16 rounded-lg bg-primary/20 flex items-center justify-center">
            <Building2 className="w-6 h-6 md:w-8 md:h-8 text-primary" />
          </div>
        </div>
        <div className="flex-1 space-y-3">
          <h3 className="font-serif text-2xl md:text-3xl font-bold text-primary">
            {companyName}
          </h3>
          <p className="text-base md:text-lg leading-relaxed text-foreground">
            {description}
          </p>
          <div className="pt-2">
            <span className="inline-block px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium">
              Stage {stageNumber}
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
}

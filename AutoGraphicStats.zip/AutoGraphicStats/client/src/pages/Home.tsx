import GameBoard from '@/components/GameBoard';
import { CompanyStage } from '@shared/schema';

export default function Home() {
  //todo: remove mock functionality - replace with real data from backend
  const gameStages: CompanyStage[] = [
    {
      id: 1,
      companyName: "Google",
      description: "A multinational technology company that specializes in Internet-related services and products, including online advertising, search engine, cloud computing, software, and hardware.",
      isUnlocked: true,
    },
    {
      id: 2,
      companyName: "Microsoft",
      description: "An American multinational technology corporation that produces computer software, consumer electronics, personal computers, and related services. Known for Windows OS and Office suite.",
      isUnlocked: false,
    },
    {
      id: 3,
      companyName: "Apple",
      description: "A multinational technology company that designs, develops, and sells consumer electronics, computer software, and online services. Famous for iPhone, iPad, and Mac computers.",
      isUnlocked: false,
    },
    {
      id: 4,
      companyName: "Amazon",
      description: "An American multinational technology company focusing on e-commerce, cloud computing, digital streaming, and artificial intelligence. One of the world's largest online retailers.",
      isUnlocked: false,
    },
    {
      id: 5,
      companyName: "Meta",
      description: "A technology company that builds platforms for connecting people, finding communities, and growing businesses. Parent company of Facebook, Instagram, and WhatsApp.",
      isUnlocked: false,
    },
  ];

  return <GameBoard initialStages={gameStages} />;
}

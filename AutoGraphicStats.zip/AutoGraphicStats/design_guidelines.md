# Design Guidelines: Lock & Key Treasure Hunt Game

## Design Approach

**Selected Approach:** Reference-Based (Game/Interactive Experience)

**Inspiration Sources:**
- Escape room puzzle aesthetics (mystery, discovery)
- Adventure game UI (Tomb Raider, Uncharted menu systems)
- Premium puzzle apps (The Room series - tactile, luxurious feel)

**Core Principles:**
- Immersive treasure hunt atmosphere with rich visuals
- Progressive revelation through unlock mechanics
- Tactile, satisfying interaction feedback
- Mystery-driven visual hierarchy

---

## Color Palette

**Dark Mode Primary (Treasure Theme):**
- Background Deep: 220 15% 12% (dark navy-blue, mysterious depth)
- Surface: 220 12% 18% (elevated panels, treasure chest containers)
- Gold Accent: 45 85% 55% (treasure gold, unlock highlights, success states)
- Bronze Secondary: 25 60% 45% (locked states, borders, subtle accents)
- Text Primary: 40 5% 95% (high contrast readability)
- Text Secondary: 40 5% 70% (descriptions, hints)

**Visual Accents:**
- Lock Icon: Bronze tones with metallic sheen
- Unlock Animation: Gold glow effects
- Error State: 0 70% 50% (subtle red for wrong answers)
- Success Glow: 45 100% 60% (bright gold burst on unlock)

---

## Typography

**Font Stack:**
- Primary: 'Cinzel' (Google Fonts) - Display font for headings, treasure hunt feel
- Secondary: 'Inter' (Google Fonts) - Body text, company descriptions, high readability

**Type Scale:**
- Hero Title: text-5xl md:text-6xl font-bold (Cinzel)
- Chest Labels: text-2xl md:text-3xl font-semibold (Cinzel)
- Company Descriptions: text-lg md:text-xl leading-relaxed (Inter)
- Input/Buttons: text-base md:text-lg font-medium (Inter)
- Progress Indicators: text-sm font-medium (Inter)

---

## Layout System

**Spacing Primitives:** Tailwind units of 4, 6, 8, 12, 16 (p-4, gap-8, mb-12, py-16)

**Responsive Grid:**
- Mobile: Single column, vertical treasure chest stack
- Tablet: max-w-4xl container, larger interactive elements
- Desktop: max-w-6xl, horizontal treasure chest arrangement for unlocked stages

**Section Structure:**
1. Hero: Full viewport height with treasure map background
2. Game Area: Centered container with treasure chest grid
3. Progress Tracker: Fixed top bar showing 5-stage progression
4. Input Zone: Prominent, always-visible answer submission area

---

## Component Library

### A. Treasure Chest Containers
- Locked State: Dark surface with bronze padlock icon, opacity-60
- Unlocked State: Gold border glow, elevated with shadow-2xl
- Active State: Pulsing gold animation, scale-105 transform
- Size: min-h-64 with responsive padding (p-6 md:p-8)

### B. Lock & Key Mechanism
- Input Field: Large, centered with treasure chest styling, border-2 border-bronze
- Submit Button: Gold gradient background, rounded-xl, shadow-lg with "Unlock" text
- Key Icon: Animated rotate on submission attempt
- Padlock Visual: SVG illustration with shackle animation on unlock

### C. Progress Indicators
- 5-Step Visual: Horizontal row of treasure chest icons
- Active Stage: Glowing gold border, bounce animation
- Completed: Green checkmark overlay, reduced opacity
- Locked: Grayscale with padlock overlay

### D. Company Description Cards
- Container: bg-surface rounded-2xl p-8 with subtle gradient overlay
- Typography: Company name in Cinzel (text-3xl), description in Inter
- Reveal Animation: Fade-up with scale transform (0.95 to 1)
- Border: 1px gold accent on unlocked state

### E. Background Elements
- Full-screen treasure map texture (use semi-transparent overlay image)
- Treasure chest illustrations scattered (decorative, not interactive)
- Depth: Multiple layers with parallax effect on scroll (very subtle)

---

## Animations

**Unlock Sequence (Critical Interaction):**
1. Padlock shakes on incorrect answer (rotate -5deg to 5deg, 0.3s)
2. Key turns and clicks on correct answer (rotate 90deg, 0.5s)
3. Chest opens with gold particle burst (scale + opacity, 0.8s)
4. Description card fades up (translate-y + opacity, 0.6s delay)

**Micro-interactions:**
- Button hover: scale-105 with brightness increase
- Chest hover (unlocked): gentle float animation (translate-y-1)
- Input focus: Gold border glow with shadow-xl
- Progress orb: Pulse animation on active stage

**Performance:** Use transform and opacity only, CSS animations via Tailwind

---

## Images

**Hero Background:**
- Large atmospheric treasure map or treasure room environment
- Dark overlay (40-50% opacity) for text contrast
- Source: Use treasure/pirate/adventure themed imagery
- Position: bg-cover bg-center with bg-fixed for parallax depth

**Decorative Elements:**
- Treasure chest SVG illustrations (via CDN or icon library)
- Gold coin accents (scatter around unlocked chests)
- Padlock/key icons from Heroicons or Font Awesome

**Image Strategy:** Background imagery for atmosphere, SVG/icons for interactive elements

---

## Responsive Behavior

**Mobile (< 768px):**
- Vertical chest stack with gap-6
- Full-width input (w-full)
- Simplified progress bar (dots instead of detailed icons)
- Reduced padding (p-4 instead of p-8)

**Tablet (768px - 1024px):**
- 2-column chest grid for unlocked stages
- max-w-3xl container
- Larger interactive targets (min-h-16 buttons)

**Desktop (> 1024px):**
- Horizontal treasure chest display
- Sidebar progress tracker option
- Enhanced animations and particle effects
- max-w-6xl container with generous whitespace

---

## Accessibility

- High contrast gold on dark ensures WCAG AA compliance
- Focus states with clear gold outline (ring-4 ring-gold)
- Keyboard navigation: Tab through chests, Enter to submit
- Screen reader: Descriptive labels for locked/unlocked states
- Error messages: Clear text feedback, not just color